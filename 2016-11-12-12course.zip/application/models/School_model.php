<?php
class school_model extends CI_Model {
	public function __construct()
	{
		$this->load->database();
	}
	public function getschoollist()
	{	
		$arr=$this->db->select('zimu')->get('school')->result_array();
		foreach ($arr as $v) {
			$arr_01=$this->db->select('schoolid,schoolname')->where('zimu=',$v['zimu'])->get('school')->result_array()	;
			$data[$v['zimu']]=$arr_01;	
		}
		return $data;	
	}
	//通过shoolid 获取wip,nip地址和学校名字
	public function  getschoolwip($schoolid)
	{
		$data=$this->db->select('wip,schoolname,nip')->where('schoolid',$schoolid)->get('school')->row_array();
		return $data;
	}

}