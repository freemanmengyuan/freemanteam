<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require('base.php');

class weixin extends base {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('user_model');
		$this->load->model('school_model');
	}
	public function index()
	{
		$code=$_GET['code'];
		if(empty($code)){
			exit('code error');
		}
		$appid='wx8b2659e6c0bd4c21';
		$secret='ebfc00bda99990381e1d86d07066d002';
		$getTokenUrl="https://api.weixin.qq.com/sns/oauth2/access_token?appid=$appid&secret=$secret&code=$code&grant_type=authorization_code";
		$accessTokenJson=file_get_contents($getTokenUrl);
		$accessTokenArr=json_decode($accessTokenJson,true);
		$accessToken=$accessTokenArr['access_token'];
		$openid=$accessTokenArr['openid'];
		if(!$openid){
			exit('openid error');
		}
		//echo $openid;exit;	
		//把openid写入SESSION
		$_SESSION['openid']=$openid;              
		$arr=$this->user_model->userinfo($openid);
		if(!empty($arr)){
			$schoolid=$arr['schoolid'];
			$wip=$this->school_model->getschoolwip($schoolid);
			//把常用值写入SESSION
			$_SESSION['userid']=$arr['userid'];
			$_SESSION['schoolid']=$arr['schoolid'];
			$_SESSION['wip']=$wip['wip'];
			//更新用户登录数据
			$truename=$arr['truename'];
			$sex=$arr['sex'];
			$facepic=$arr['facepic'];
			$birthday=$arr['birthday'];
			$specialname=$arr['specialname'];
			$data_p=array(
				'truename'=>$truename,
				'sex'=>$sex,
				'facepic'=>$facepic,
				'birthday'=>$birthday,
				'specialname'=>$specialname,
			);
			$result=$this->db->where("openid='".$openid."'")->update('user',$data_p);
			if(empty($result)){
				exit('用户信息更新失败');
			}
			//进入不同菜单页面2016-5-10 18:28:03
			switch($_GET['state']){
				case 'calldo':        //我的课程
					$url='/wap/htmlv/course/myCourse.html';
					break;
				case 'userinfo':      //个人中心
					$url='/wap/htmlv/penrson/center.html';
					break;
				case 'homework':     
					$url='/wap/htmlv/homework/my.html';
					break;
				case 'exam':
					$url='/wap/htmlv/exam/my.html';
					break;
				default:
					$url='/wap/htmlv/course/myCourse.html';
			}
			//直接跳转到相应页面
			header("location:".$url);
		}else{
			//跳转至登录准备页面
			header("location:/wap/htmlv/user/guide.html");
		}
	}
}





	
	

