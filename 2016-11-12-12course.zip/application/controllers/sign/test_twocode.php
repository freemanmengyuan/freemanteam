<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require('base.php');

class test_twocode extends base{
	function index(){
		echo "<h2>Hello world!</h2>";
	}
	
}
