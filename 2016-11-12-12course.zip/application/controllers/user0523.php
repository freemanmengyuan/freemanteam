<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require('base.php');
class user extends base {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('user_model');
		$this->load->model('school_model');
	}
   //用户登录
	public function userlogin()
	{ 
		//校验key
		$key=$this->input->post('key');
	//print_r($key);exit();
		if(empty($key)){
			$data=$this->httpCode(611,'参数为空','');
		}else{
			if($this->apikey($key)){
				//接收参数
				$username=$this->input->post('username');
				$password=$this->input->post('password');
				$schoolid=$this->input->post('schoolid');
				//$openid  =$this->input->post('openid');
				$openid=$_SESSION['openid'];
				//判断post接收的数据
				if(empty($username) || empty($password) || empty($schoolid) || empty($openid)){
					$data=$this->httpCode(611,'用户名、密码、学校均不能为空','');
				}else{
					//判断是否已经绑定登录
					$string='openid="'.$openid.'" or ( username="'.$username.'" and schoolid='.$schoolid.')';
					$result_a=$this->user_model->judgelogin($string);
					if($result_a=='yes'){
						$data=$this->httpCode(304,'您的账号已绑定其他设备，请解绑后再登录','');
					}else{
						$wip=$this->school_model->getschoolwip($schoolid);
						$url=$wip['wip'].'/api/login/index';
						$datastring['username']=$username;                
						$datastring['password']=$password;        
						$datastring=http_build_query($datastring);
						$data_user=$this->curl($url,$datastring);
						$data_user_arr=json_decode($data_user,true);
						//判断数据
						if(!is_array($data_user_arr)){
							$data=$this->httpCode(505,'系统繁忙','');
						}else{
							//判断登录错误信息
							$code=$data_user_arr['code'];
							if($code==300){
								$data=$this->httpCode(300,'用户名不能为空','');
								echo json_encode($data);
								die();
							}
							if($code==400){
								$data=$this->httpCode(400,'密码不能为空','');
								echo json_encode($data);
								die();
							}
							if($code==500){
								$data=$this->httpCode(500,'用户名不存在','');
								echo json_encode($data);
								die();
							}	
							if($code==600){
								$data=$this->httpCode(600,'密码错误','');
								echo json_encode($data);
								die();
							}
							if($code==100){
								$userid=$data_user_arr['data']['id'];
								$roleid=$data_user_arr['data']['roleid'];
								$result['userid']=$userid;
								$result['schoolid']=$schoolid;
								$result['roleid']=$roleid;
								$result['wip']=$wip['wip'];
								$result['nip']=$wip['nip'];
								//把用户信息写入user表	
								$arr=array(
									'username'=>$username,
									'userid'=>$userid,
									'schoolid'=>$schoolid,
									'openid'=>$openid,	
									'roleid'=>$roleid,
									'addtime'=>date('Y-m-d H:i:s',time()),
								 );
								 $insert_result=$this->user_model->insertuserinfo($arr);
								 if($insert_result){
									 $result['status']=1;
									 $data=$this->httpCode(208,'登录并绑定成功',$result);
									 $_SESSION['userid']=$userid;
									 $_SESSION['schoolid']=$schoolid;
									 $_SESSION['wip']=$wip['wip'];
								 }else{
									 $result['status']=0;
									 $data=$this->httpCode(504,'用户绑定失败',$result);
								 }
							 }
						}		
					}
					
					
				}
			}else{
				$data=$this->httpCode(601,'key校验失败','');
			}
		}
		echo    json_encode($data);	
	}
}
